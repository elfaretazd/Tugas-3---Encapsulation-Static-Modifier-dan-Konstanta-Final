package praktic.geometry.bases;

public abstract class Shape {
    private String name;
    public Shape() { this.name = "Unknown Shape"; }
    public void setName(String inputName) { this.name = inputName; }
    public String getName() { return name; }
    public abstract void printInfo();
}
