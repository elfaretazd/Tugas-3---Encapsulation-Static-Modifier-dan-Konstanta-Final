package praktic.geometry.interfaces;

public interface TwoDimensional {
    double getArea();
    double getPerimeter();
}
