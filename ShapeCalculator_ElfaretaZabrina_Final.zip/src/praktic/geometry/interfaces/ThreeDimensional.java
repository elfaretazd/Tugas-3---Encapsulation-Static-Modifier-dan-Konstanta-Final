package praktic.geometry.interfaces;

public interface ThreeDimensional {
    double getSurfaceArea();
    double getVolume();
}
