package praktic.geometry.interfaces;

public interface Weightable {
    double g = 9.8;
    double getWeight();
}
